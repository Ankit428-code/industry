
export const SUBMIT_RATING_REQUEST = "SUBMIT_RATING_REQUEST";
export const SUBMIT_RATING_SUCCESS = "SUBMIT_RATING_SUCCESS";
export const SUBMIT_RATING_FAILURE = "SUBMIT_RATING_FAILURE";

export const submitRatingRequest = (productId, rating, comment) => ({
  type: SUBMIT_RATING_REQUEST,
  payload: { productId, rating, comment },
});

export const submitRatingSuccess = () => ({
  type: SUBMIT_RATING_SUCCESS,
});

export const submitRatingFailure = (error) => ({
  type: SUBMIT_RATING_FAILURE,
  payload: error,
});
