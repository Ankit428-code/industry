import { SUBMIT_RATING, SUBMIT_RATING_RED } from "../Constants";

const initialState = {
    ratings: {}, // Object to store ratings by productId
    reviews: {}, // Object to store reviews by productId
  };

  export default function RatingSubmit(state = initialState, action){
    switch (action.type) {
        case SUBMIT_RATING:
          const { productId, rating, comment } = action.payload;
          return {
            ...state,
            ratings: {
              ...state.ratings,
              [productId]: rating,
            },
            reviews: {
              ...state.reviews,
              [productId]: comment,
            },
          };
        default:
          return state;
      }
  }