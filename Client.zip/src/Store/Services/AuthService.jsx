import { apiLink } from "../../utils/utils";

// Fetch Authenticated user
export const FetchUser = async () =>{
    const response = await fetch(`${apiLink}/user`, {withCredentials: true});
    return response.data;
};

// Logout User
// export const Logout = async() =>{
//     await fetch(`${apiLink}/logout`)
// };