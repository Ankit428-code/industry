import { apiLink } from "../../utils/utils";

export async function addProductAPI(data) {
  var response = await fetch(`${apiLink}/api/product`, {
    method: "post",
    headers: {
      authorization: localStorage.getItem("token"),
    },
    body: data,
  });
  return await response.json();
}
export async function getProductAPI(data) {
  var response = await fetch(`${apiLink}/api/product`, {
    method: "get",
    headers: {
      "content-type": "application/json",
    },
  });
  return await response.json();
}
export async function getProductByMainCategoryAPI(id) {
  var response = await fetch(`${apiLink}/api/productByMainCategory/${id}`, {
    method: "get",
    headers: {
      "content-type": "application/json",
    },
  });
  return await response.json();
}
export async function getProductBySubCategoryAPI(id) {
  var response = await fetch(`${apiLink}/api/productBySubCategory/${id}`, {
    method: "get",
    headers: {
      "content-type": "application/json",
    },
  });
  return await response.json();
}
export async function getProductByBrandAPI(id) {
  var response = await fetch(`${apiLink}/api/productByBrand/${id}`, {
    method: "get",
    headers: {
      "content-type": "application/json",
    },
  });
  return await response.json();
}
export async function deleteProductAPI(data) {
  var response = await fetch(`${apiLink}/api/product/` + data._id, {
    method: "delete",
    headers: {
      "content-type": "application/json",
      authorization: localStorage.getItem("token"),
    },
  });
  return await response.json();
}
export async function updateProductAPI(data) {
  var response = await fetch(`${apiLink}/api/product/` + data._id, {
    method: "put",
    headers: {
      authorization: localStorage.getItem("token"),
    },
    body: data.data,
  });
  return await response.json();
}
