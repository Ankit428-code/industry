
import { takeLatest, call, put } from "redux-saga/effects";
import * as api from "./api"; // Your API functions
import {
  SUBMIT_RATING_REQUEST,
  submitRatingSuccess,
  submitRatingFailure,
} from "./actions";

function* submitRatingSaga(action) {
  try {
    const { productId, rating, comment } = action.payload;
    // Call your API to submit the rating
    yield call(api.submitRating, productId, rating, comment);
    yield put(submitRatingSuccess());
  } catch (error) {
    yield put(submitRatingFailure(error));
  }
}

function* rootSaga() {
  yield takeLatest(SUBMIT_RATING_REQUEST, submitRatingSaga);
}

export default rootSaga;
