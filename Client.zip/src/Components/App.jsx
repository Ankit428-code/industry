import React from "react";

import { BrowserRouter, Routes, Route } from "react-router-dom";
import Cart from "./Cart";
import Checkout from "./Checkout";
import Order from "./Order";
import Contact from "./Contact";
import Footer from "./Footer";
import Home from "./Home";
import Navbar from "./Navbar";
import Shop from "./Shop";
import SingleProduct from "./SingleProduct";

import AdminHome from "./Admin/AdminHome";
import Maincategory from "./Admin/Maincategory";
import AddMaincategory from "./Admin/AddMaincategory";
import UpdateMaincategory from "./Admin/UpdateMaincategory";
import Subcategory from "./Admin/Subcategory";
import AddSubcategory from "./Admin/AddSubcategory";
import UpdateSubcategory from "./Admin/UpdateSubcategory";
import Brand from "./Admin/Brand";
import AddBrand from "./Admin/AddBrand";
import UpdateBrand from "./Admin/UpdateBrand";
import Product from "./Admin/Product";
import AddProduct from "./Admin/AddProduct";
import UpdateProduct from "./Admin/UpdateProduct";
import Login from "./Login";
import Signup from "./Signup";
import Profile from "./Profile";
import UpdateProfile from "./UpdateProfile";
import Confirmation from "./Confirmation";
import Newslatter from "./Admin/Newslatter";
import Users from "./Admin/Users";
import AdminContact from "./Admin/AdminContact";
import AdminSingleContact from "./Admin/AdminSingleContact";
import AdminCheckout from "./Admin/AdminCheckout";
import AdminSinglecheckout from "./Admin/AdminSingleCheckout";
import ForgetPassword1 from "./ForgetPassword1";
import ForgetPassword2 from "./ForgetPassword2";
import ForgetPassword3 from "./ForgetPassword3";
import Payment from "./Payment";
import About from "./About";
import CreateAccount from "./CreateAccount";
import Wishlist from "./Wishlist";
import RatingPage from "./Rating";

//////////////////// Vendor /////////////////////

import VendorHome from "./Vendor/VendorHome";
import VendorMaincategory from "./Vendor/VendorMaincategory";
import VendorSubcategory from "./Vendor/VendorSubcategory";
import VendorBrand from "./Vendor/VendorBrand";
import VendorProduct from "./Vendor/VendorProduct";
import VendorAddProduct from "./Vendor/VendorAddProduct";
import VendorUpdateProduct from "./Vendor/VendorUpdateProduct";
import ProductRatingForm from "./ProductRatingForm";
import Pole1 from "./Pole1";
import Pole2 from "./Pole2";
// eslint-disable-next-line
export default function App() {
  return (
    <BrowserRouter>

      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/shop/:maincat/:subcat/:brnd" element={<Shop />} />
        <Route path="/single-product/:_id" element={<SingleProduct />} />
        <Route path="/rate-product" element={<ProductRatingForm/>} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/forget-password-1" element={<ForgetPassword1 />} />
        <Route path="/forget-password-2" element={<ForgetPassword2 />} />
        <Route path="/forget-password-3" element={<ForgetPassword3 />} />
        <Route path="/createaccount" element={<CreateAccount />} />
        <Route path="/wishlist" element={<Wishlist />} />
        <Route path="/rating" element={<RatingPage />} />
        <Route
          path="/confirmation"
          element={localStorage.getItem("login") ? <Confirmation /> : <Login />}
        />
        <Route
          path="/payment/:_id"
          element={localStorage.getItem("login") ? <Payment /> : <Login />}
        />
        <Route
          path="/profile"
          element={localStorage.getItem("login") ? <Profile /> : <Login />}
        />
        <Route
          path="/update-profile"
          element={
            localStorage.getItem("login") ? <UpdateProfile /> : <Login />
          }
        />
        <Route
          path="/cart"
          element={localStorage.getItem("login") ? <Cart /> : <Login />}
        />
        <Route
          path="/checkout"
          element={localStorage.getItem("login") ? <Checkout /> : <Login />}
        />
        <Route
          path="/order"
          element={localStorage.getItem("login") ? <Order /> : <Login />}
        />
        <Route path="/about" element={<About />} />

        {/* Admin */}

        <Route
          path="/admin"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <AdminHome />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-maincategories"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <Maincategory />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-add-maincategory"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <AddMaincategory />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-update-maincategory/:_id"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <UpdateMaincategory />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-subcategories"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <Subcategory />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-add-subcategory"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <AddSubcategory />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-update-subcategory/:_id"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <UpdateSubcategory />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-brands"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <Brand />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-add-brand"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <AddBrand />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-update-brand/:_id"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <UpdateBrand />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-products"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <Product />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-add-product"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <AddProduct />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-update-product/:_id"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <UpdateProduct />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-newslatters"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <Newslatter />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-users"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <Users />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-contacts"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <AdminContact />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-single-contact/:_id"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <AdminSingleContact />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-checkouts"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <AdminCheckout />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin-single-checkout/:_id"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Admin" ? (
                <AdminSinglecheckout />
              ) : (
                <Profile />
              )
            ) : (
              <Login />
            )
          }
        />

        {/* \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\           Vendor           ////////////////////////////////// */}

        <Route
          path="/vendor"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Vendor" ? (
                <VendorHome />
              ) : (
                <Login />
              )
            ) : (
              ""
            )
          }
        />
        <Route
          path="/vendor-maincategories"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Vendor" ? (
                <VendorMaincategory />
              ) : (
                <Login />
              )
            ) : (
              ""
            )
          }
        />
       
       
        <Route
          path="/vendor-subcategories"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Vendor" ? (
                <VendorSubcategory />
              ) : (
                <Login />
              )
            ) : (
              ""
            )
          }
        />
       
        
        <Route
          path="/vendor-brands"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Vendor" ? (
                <VendorBrand />
              ) : (
                <Login />
              )
            ) : (
              ""
            )
          }
        />
       
        
        <Route
          path="/vendor-products"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Vendor" ? (
                <VendorProduct />
              ) : (
                <Login />
              )
            ) : (
              ""
            )
          }
        />
        <Route
          path="/vendor-add-product"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Vendor" ? (
                <VendorAddProduct />
              ) : (
                <Login />
              )
            ) : (
              ""
            )
          }
        />
        <Route
          path="/vendor-update-product/:_id"
          element={
            localStorage.getItem("login") ? (
              localStorage.getItem("role") === "Vendor" ? (
                <VendorUpdateProduct />
              ) : (
                <Login />
              )
            ) : (
              ""
            )
          }
        />
        <Route path="/pole1" element={<Pole1 />} />
        <Route path="/pole2" element={<Pole2/>}/>
      </Routes>
      <Footer />
    </BrowserRouter>
  );
}
