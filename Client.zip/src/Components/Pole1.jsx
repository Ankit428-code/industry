
import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Dropdownbtn from "./Dropdownbtn";
import { getProduct } from "../Store/ActionCreators/ProductActionCreators";
import { getCart, addCart } from "../Store/ActionCreators/CartActionCreators";
import {
    getWishlist, addWishlist,
} from "../Store/ActionCreators/WishlistActionCreators";
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import { Typography } from "@mui/material";





import ProductRatingForm from "./ProductRatingForm";

import { Link, useNavigate, useParams } from "react-router-dom";
import { apiLink } from "../utils/utils";

export default function Pole1({ productId }) {

    const [reviews, setReviews] = useState([]);
    const [ratings, setRatings] = useState([]);
    const [averageRating, setAverageRating] = useState(0);
    const [totalReviews, setTotalReviews] = useState(0);

    const date = new Date(new Date().getTime() + 5 * 24 * 60 * 60 * 1000);
    let [relatedProducts, setRelatedProducts] = useState([]);
    const [showRatingForm, setShowRatingForm] = useState(false);

    var [product, setProduct] = useState({
        pic1: "",
        pic2: "",
        pic3: "",
        pic4: "",
    });
    var [qty, setQty] = useState(1);
    var dispatch = useDispatch();
    var allProducts = useSelector((state) => state.ProductStateData);
    var allCarts = useSelector((state) => state.CartStateData);
    var allWishlists = useSelector((state) => state.WishlistStateData);
    var navigate = useNavigate();
    var { _id } = useParams();
    
    // console.log("ProductStateData after dispatch:",useSelector((state) => state.ProductStateData))

    const [showDescription, setShowDescription] = useState(true);

    const addReview = (newReview) => {
        setReviews([...reviews, newReview]);
    };
    const addRating = (newRating) => {
        setRatings([...ratings, newRating]);
    };
   


    const handleRatingSubmit = (newRating) => {
        // Update state with the submitted rating and review
        setRatings([...ratings, newRating.rating]);
        setReviews([...reviews, newRating.comment]);
    };

    const handleDescriptionClick = () => {
        setShowDescription(true);
    };

    const handleSpecificationClick = () => {
        setShowDescription(true);
    };

    const handleRateProductClick = () => {
        setShowRatingForm(true);
    };

     const   getAPIData = async()=> {
        dispatch(getProduct());
        dispatch(getCart());
        dispatch(getWishlist());
        console.log("checking allproduct",allProducts);
        console.log("checking id", _id)
        if (allProducts.length) {
          var item =await allProducts.find((x) => x._id === _id);
          if (item) {
            setProduct(item);
            setRelatedProducts(
              allProducts.filter(
                (x) =>
                  x.maincategory === item.maincategory &&
                  x.subcategory === item.subcategory &&
                  x.brand === item.brand
              )
            );
          } else {
             //navigate("/shop");
          }
        }
      }

    function addToCart() {
        var item = allCarts.find(
            (x) => x.userid === localStorage.getItem("userid") && x.productid === _id
        );
        if (item) navigate("/cart");
        else {
            var item = {
                userid: localStorage.getItem("userid"),
                productid: _id,
                name: product.name,
                color: product.color,
                size: product.size,
                brand: product.brand,
                price: product.finalprice,
                qty: qty,
                total: product.finalprice * qty,
                pic: product.pic1,
                review: product.review,
                rating: product.rating,
            };
            dispatch(addCart(item));
            navigate("/cart");
        }
    }
    function addToWishlist() {
        var item = allWishlists.find(
            (x) => x.userid === localStorage.getItem("userid") && x.productid === _id
        );
        if (item) navigate("/wishlist");
        else {
            var item = {
                userid: localStorage.getItem("userid"),
                productid: _id,
                name: product.name,
                color: product.color,
                size: product.size,
                brand: product.brand,
                price: product.finalprice,
                pic: product.pic1,
                review: product.review,
                rating: product.rating,
            };
            dispatch(addWishlist(item));
            navigate("/profile");
        }
    }
    useEffect(() => {
        // Other existing useEffect code

        // Calculate average rating and total reviews when ratings change
        if (ratings.length > 0) {
            const totalRating = ratings.reduce((acc, rating) => acc + rating, 0);
            const avgRating = totalRating / ratings.length;
            setAverageRating(avgRating);
            setTotalReviews(ratings.length);
        } else {
            // If there are no ratings, reset average rating and total reviews
            setAverageRating(0);
            setTotalReviews(0);
        }
    }, [ratings]);
      useEffect(() => {
        
        getAPIData();
        // eslint-disable-next-line
    }, [allProducts.length, allCarts.length, allWishlists.length]);

    return (
        <>
            <div className="container-fluid pb-5">
                <div className="row px-xl-5">
                    <div className="col-lg-5 mb-30">
                        <div id="carouselExampleIndicators" className="carousel slide">
                            <div className="carousel-indicators">
                                <button
                                    type="button"
                                    data-bs-target="#carouselExampleIndicators"
                                    data-bs-slide-to="0"
                                    className="active"
                                    aria-current="true"
                                    aria-label="Slide 1"
                                ></button>
                                <button
                                    type="button"
                                    data-bs-target="#carouselExampleIndicators"
                                    data-bs-slide-to="1"
                                    aria-label="Slide 2"
                                ></button>
                                <button
                                    type="button"
                                    data-bs-target="#carouselExampleIndicators"
                                    data-bs-slide-to="2"
                                    aria-label="Slide 3"
                                ></button>
                                <button
                                    type="button"
                                    data-bs-target="#carouselExampleIndicators"
                                    data-bs-slide-to="3"
                                    aria-label="Slide 4"
                                ></button>
                            </div>
                            <div className="carousel-inner">
                                <div className="carousel-item active">
                                    <img
                                        className="d-block w-100"
                                        src={`${apiLink}/public/users/${product.pic1}`}
                                        height="525px"
                                        alt="..."
                                    />
                                </div>
                                <div className="carousel-item">
                                    <img
                                        className="d-block w-100"
                                        src={`${apiLink}/public/products/${product.pic2}`}
                                        height="525px"
                                        alt="..."
                                    />
                                </div>
                                <div className="carousel-item">
                                    <img
                                        className="d-block w-100"
                                        src={`${apiLink}/public/products/${product.pic3}`}
                                        height="525px"
                                        alt="..."
                                    />
                                </div>
                                <div className="carousel-item">
                                    <img
                                        className="d-block w-100"
                                        src={`${apiLink}/public/products/${product.pic4}`}
                                        height="525px"
                                        alt="..."
                                    />
                                </div>
                            </div>
                            <a
                                className="carousel-control-prev"
                                href="#product-carousel"
                                data-slide="prev"
                            >
                                <i className="fa fa-2x fa-angle-left text-dark"></i>
                            </a>
                            <a
                                className="carousel-control-next"
                                href="#product-carousel"
                                data-slide="next"
                            >
                                <i className="fa fa-2x fa-angle-right text-dark"></i>
                            </a>
                        </div>
                        <div className="d-flex justify-content-between mt-1">
                            <img
                                src={`${apiLink}/public/products/${product.pic1}`}
                                height="100px"
                                width="24.7%"
                                alt=""
                                data-bs-target="#carouselExampleIndicators"
                                data-bs-slide-to="0"
                                className="active"
                                aria-current="true"
                                aria-label="Slide 1"
                            />
                            <img
                                src={`${apiLink}/public/products/${product.pic2}`}
                                height="100px"
                                width="24.7%"
                                alt=""
                                data-bs-target="#carouselExampleIndicators"
                                data-bs-slide-to="1"
                                aria-label="Slide 2"
                            />
                            <img
                                src={`${apiLink}/public/products/${product.pic3}`}
                                height="100px"
                                width="24.7%"
                                alt=""
                                data-bs-target="#carouselExampleIndicators"
                                data-bs-slide-to="2"
                                aria-label="Slide 3"
                            />
                            <img
                                src={`${apiLink}/public/products/${product.pic4}`}
                                height="100px"
                                width="24.7%"
                                alt=""
                                data-bs-target="#carouselExampleIndicators"
                                data-bs-slide-to="3"
                                aria-label="Slide 4"
                            />
                        </div>
                        <div className="d-flex align-items-center mb-2  pt-2 ">
                            <button className="btn main-color px-5 w-50" onClick={addToCart}>
                                <i className="fa fa-shopping-cart mr-1"></i> Buy Now
                            </button>
                            <button
                                className="btn btn-danger px-3 w-50"
                                onClick={addToWishlist}
                            >
                                <i className="fa fa-heart mr-1"></i> Add To Wishlist
                            </button>
                        </div>
                    </div>

                    <div className="col-lg-7 h-auto mb-30 ">
                        <div className="h-100 bg-light p-30 ">
                            <h6>
                                {product?.maincategory?.name}/{product?.subcategory?.name}/
                                {product?.brand?.name}
                            </h6>
                            <h5>{product.name}</h5>
                            <Typography
                                style={{ marginTop: 5, color: "#878787", fontSize: 14 }}
                            >
                                {averageRating.toFixed(1)} ({totalReviews} Reviews)
                            </Typography>
                            <h6 className="font-weight-semi-bold mb-4">
                                <del className="text-danger">&#8377;{product.baseprice}</del>
                                &#8377; {product.finalprice}
                                <sup className="text-success">{product.discount}% OFF</sup>
                            </h6>

                            <div>
                                <div>
                                    <button
                                        className="btn main-color px-3 mr-4 mb-3"
                                        onClick={handleDescriptionClick}
                                    >
                                        {" "}
                                        Description
                                    </button>
                                    <button
                                        className="btn main-color px-3 mr-4 mb-3"
                                        onClick={handleSpecificationClick}
                                    >
                                        Specification
                                    </button>
                                </div>
                                {showDescription && (
                                    <p className="mb-4">{product.description}</p>
                                ) ? (
                                    <p className="mb-4">{product.description}</p>
                                ) : (
                                    <table style={{ width: "100%" }}>
                                        <tbody className="text-dark m-3">
                                            {product.specification.map((item, i) => (
                                                <tr key={i}>
                                                    <th>{item.key}</th>
                                                    <td>:</td>
                                                    <td style={{ width: "60%", color: "#6068bf" }}>{item.value}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                )}
                            </div>
                            <div className="d-flex mb-1">
                                <strong className="text-dark mr-3">Size:</strong>
                                <p>{product.size}</p>
                            </div>
                            <div className="d-flex mb-1">
                                <strong className="text-dark mr-3">Color:</strong>
                                <p>{product.color}</p>
                            </div>
                            <div>
                                <div className="d-flex mb-1">
                                    <strong className="text-dark mr-3">Delievery:</strong>
                                    <p className="text-dark" style={{ fontWeight: 600 }}>
                                        Delievery by {date.toDateString()}
                                    </p>
                                </div>
                            </div>

                            <div className=" d-flex gap-5 px-3 mr-4 mb-3">
                                <h6>Ratings & Reviews</h6>
                                <Link to="/rate-product" className="btn-sm main-color mr-6" onClick={handleRateProductClick}>
                                    Rate Product
                                </Link>
                            </div>
                            {/* <ProductRatingForm productId={productId} onRatingSubmit={handleRatingSubmit} /> */}
                            {/* ===================== */}
                            <div>
                                <Dropdownbtn />

                            </div>
                        </div>
                    </div>
                </div>

                {relatedProducts.length ? (
                    <>
                        <h6 className="text-center my-3 main-color p-2">
                            Products You May Also Like
                        </h6>

                        <OwlCarousel
                            className="owl-theme"
                            loop
                            margin={10}
                            nav
                            responsive={{
                                450: { items: 2 },
                                576: { items: 3 },
                                768: { items: 4 },
                                992: { items: 5 },
                                1200: { items: 6 },
                            }}
                        >
                            {relatedProducts.map((item, index) => {
                                
                                return (
                                    <div
                                        className="wow fadeInUp"
                                        key={index}
                                        data-wow-delay="0.1s"
                                    >
                                        <div className="team-item">
                                            <div className="position-relative overflow-hidden">
                                                <img
                                                    className="img-fluid"
                                                    src={`${apiLink}/public/products/${item.pic1}`}
                                                    style={{ height: "230px", width: "100%" }}
                                                    alt=""
                                                />
                                                <div className="team-overlay position-absolute start-0 top-0 w-100 h-100">
                                                    <img
                                                        src={`${apiLink}/public/products/${item.pic1}`}
                                                        className="position-absolute start-0 top-0 w-100 h-100"
                                                        style={{ height: "230px", width: "100%" }}
                                                        alt=""
                                                    />
                                                    <Link
                                                        className="btn main-color px-3 w-100 position-absolute start-0 bottom-0 w-100 h-100'"
                                                        onClick={addToCart}
                                                    >
                                                        <i className="fa fa-shopping-cart"></i> Add to Cart
                                                    </Link>
                                                </div>
                                            </div>
                                            <div className="bg-light text-center p-3">
                                                <h6 className="fw-bold mb-0" style={{ height: "50px" }}>
                                                    {item.name}
                                                </h6>
                                                <small>
                                                    <del className="text-danger">
                                                        &#8377;{item.baseprice}
                                                    </del>{" "}
                                                    &#8377;{item.finalprice}{" "}
                                                    <sup className="text-success">
                                                        {item.discount}% off
                                                    </sup>
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </OwlCarousel>
                    </>
                )
                 : (
                    ""
                )}
            </div>
        </>
    );
}



