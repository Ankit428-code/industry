import React, { useState } from "react";
import { addContactUs } from "../Store/ActionCreators/ContactUsActionCreators";
import { useDispatch } from "react-redux";
export default function Contact() {
  var [data, setData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });
  var [show, setShow] = useState(false);
  var dispatch = useDispatch();
  function getInputData(e) {
    var { name, value } = e.target;
    setData((old) => {
      return {
        ...old,
        [name]: value,
      };
    });
    setShow(false);
  }
  function postData(e) {
    e.preventDefault();
    var item = {
      name: data.name,
      email: data.email,
      phone: data.phone,
      subject: data.subject,
      message: data.message,
      status: "Active",
      date: new Date(),
    };
    dispatch(addContactUs(item));
    setShow(true);
    setData({
      name: "",
      email: "",
      phone: "",
      subject: "",
      message: "",
    });
  }
  return (
    <>
      <div className="container-fluid">
        <h2 className="section-title position-relative text-uppercase mx-xl-5 mb-4 text-center">
          <span className="bg-secondary pr-3">Contact Us</span>
        </h2>
        <div className="row px-xl-5">
          <div className="col-lg-7 mb-5 ">
            <div className="bg-light p-30">
              {show ? (
                <div
                  className="alert alert-success text-center alert-dismissible fade show"
                  role="alert"
                >
                  Thanks to Share Your Query With Us!!! Our Team Will Contact
                  Your Soon!!!
                  <button
                    type="button"
                    className="btn-close"
                    data-bs-dismiss="alert"
                    aria-label="Close"
                  ></button>
                </div>
              ) : (
                ""
              )}
              <form onSubmit={postData}>
                <div className="control-group mb-2">
                  <input
                    type="text"
                    className="form-control"
                    name="name"
                    value={data.name}
                    onChange={getInputData}
                    placeholder="Your Name"
                    required
                  />
                </div>
                <div className="control-group mb-2">
                  <input
                    type="email"
                    className="form-control"
                    name="email"
                    value={data.email}
                    onChange={getInputData}
                    placeholder="Your Email"
                    required
                  />
                </div>
                <div className="control-group mb-2">
                  <input
                    type="text"
                    className="form-control"
                    name="phone"
                    value={data.phone}
                    onChange={getInputData}
                    placeholder="Your Phone"
                    required
                  />
                </div>
                <div className="control-group mb-2">
                  <input
                    type="text"
                    className="form-control"
                    name="subject"
                    value={data.subject}
                    onChange={getInputData}
                    placeholder="Subject"
                    required
                  />
                </div>
                <div className="control-group mb-2">
                  <textarea
                    className="form-control"
                    rows="10"
                    name="message"
                    value={data.message}
                    onChange={getInputData}
                    placeholder="Message"
                    required
                  ></textarea>
                </div>
                <div style={{ boxShadow: "1px 3px 8px", borderRadius: "12px" }}>
                  <button
                    className="btn main-color py-2 px-4 w-100"
                    type="submit"
                  >
                    SendMessage
                  </button>
                </div>
              </form>
            </div>
          </div>
          <div className="col-lg-5 mb-5">
            <div className="bg-light p-30 mb-30">
              <div className="mapouter">
                <div className="gmap_canvas">
                  <iframe
                    width="100%"
                    height="300px"
                    name="gmap_canvas"
                    src="https://maps.google.com/maps?q=Khasra%20No:%20401,%20402,%20First%20Floor,%20Ghitorni,%20Delhi%20-%20110030&t=&z=13&ie=UTF8&iwloc=&output=embed"
                    frameBorder="0"
                    scrolling="no"
                    marginHeight="0"
                    marginWidth="0"
                  ></iframe>
                </div>
              </div>
            </div>
            <div className="bg-light p-30 mb-3">
              <p className="mb-2">
                <h3>OPTIMA CONNECT PVT. LTD.</h3>
                <h5 style={{ marginBottom: "1rem" }}>
                  CIN : U47912UP2023PTC193933
                </h5>
                <i className="fa fa-map-marker-alt text-primary mr-3"></i> Plot
                no. 11, Kharsa No. 921, New Karhera Colony, <br />{" "}
                <span style={{ marginLeft: "2rem" }}>
                  Mohan Nagar, Gaahaziabad, U.P - 201007
                </span>
              </p>
              <p className="mb-2">
                <i className="fa fa-envelope text-primary mr-3"></i>
                <a
                  href="mailto:vishankchauhan@gmail.com"
                  className="text-dark"
                  target="_blank"
                >
                  industryguruinfo@gmail.com
                </a>
              </p>
              <p className="mb-2">
                <i className="fa fa-phone-alt text-primary mr-3"></i>
                <a href="tel:9874563210" className="text-dark" target="_blank">
                  +91 9810092418
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
