// import React, { useState } from "react";
// import { FaStar } from "react-icons/fa";

// const ProductRatingForm = () => {
//   const [rating, setRating] = useState(null);
//   const [hover, setHover] = useState(null);

//   const handleRatingClick = (value) => {
//     setRating(value);
//   };

//   return (
//     <div className="container">
//       <h3  className="mb-3 text-center">Rate This Product</h3>
//       {/* Star Rating */}
//       <div className="mb-3 d-flex align-items-center justify-content-center">
//         {[...Array(5)].map((_, index) => {
//           const ratingValue = index + 1;

//           return (
//             <label key={index} className="star-label">
//               <input
//                 type="radio"
//                 name="rating"
//                 value={ratingValue}
//                 onClick={() => handleRatingClick(ratingValue)}
//                 style={{ display: "none" }}
//               />
//               <FaStar
//                 className="star-icon"
//                 color={ratingValue <= (hover || rating) ? "#ffc107" : "#878eab"}
//                 size={22}
//                 onMouseEnter={() => setHover(ratingValue)}
//                 onMouseLeave={() => setHover(null)}
//                 style={{ marginRight: "5px", stroke: "#000", strokeWidth: 1, strokeLinejoin: "round" }}
//               />
//             </label>
//           );
//         })}
//       </div>
//       {/* Comment Input */}
//       <div className="mb-3">
//         <label htmlFor="comment" className="form-label">
//           Comment:
//         </label>
//         <textarea
//           id="comment"
//           className="form-control"
//           placeholder="Add your comment..."
//           rows="4"
//           style={{ resize: "none" }}
//         ></textarea>
//       </div>
//       {/* Submit Button */}
//      <div className="d-flex justify-content-end">
//      <button type="submit" className="btn main-color ">
//         Submit Rating
//       </button>
//      </div>
//     </div>
//   );
// };

// export default ProductRatingForm;


// ProductRatingForm.js

import React, { useState } from "react";
import { FaStar } from "react-icons/fa";
import { useDispatch } from "react-redux";
import { submitRatingRequest } from "../Store/ActionCreators/RatingActionCreator";

const ProductRatingForm = ({ productId, onRatingSubmit }) => {
  const [rating, setRating] = useState(null);
  const [hover, setHover] = useState(null);
  const [comment, setComment] = useState("");
  const dispatch = useDispatch();

  const handleRatingClick = (value) => {
    setRating(value);
  };

  const handleSubmit = () => {
    dispatch(submitRatingRequest(productId, rating, comment));
    onRatingSubmit( {rating, comment});
    setRating(null);
    setHover(null);
    setComment("");
  };

  return (
    <div className="container">
      <h3 className="mb-3 text-center">Rate This Product</h3>
      <div className="mb-3 d-flex align-items-center justify-content-center">
        {[...Array(5)].map((_, index) => {
          const ratingValue = index + 1;

          return (
            <label key={index} className="star-label">
              <input
                type="radio"
                name="rating"
                value={ratingValue}
                onClick={() => handleRatingClick(ratingValue)}
                style={{ display: "none" }}
              />
              <FaStar
                className="star-icon"
                color={ratingValue <= (hover || rating) ? "#ffc107" : "#878eab"}
                size={22}
                onMouseEnter={() => setHover(ratingValue)}
                onMouseLeave={() => setHover(null)}
                style={{ marginRight: "5px", stroke: "#000", strokeWidth: 1, strokeLinejoin: "round" }}
              />
            </label>
          );
        })}
      </div>
      <div className="mb-3">
        <label htmlFor="comment" className="form-label">
        Comment:
        </label>
        <textarea
          id="comment"
          className="form-control"
          placeholder="Add your comment..."
          rows="4"
          style={{ resize: "none" }}
          value={comment}
          onChange={(e) => setComment(e.target.value)}
        ></textarea>
      </div>
      <div className="d-flex justify-content-end">
        <button type="submit" className="btn main-color" onClick={handleSubmit}>
          Submit Rating
        </button>
      </div>
    </div>
  );
};

export default ProductRatingForm;
