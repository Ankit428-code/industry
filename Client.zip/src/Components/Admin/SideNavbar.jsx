import React from "react";
import { Link } from "react-router-dom";

export default function SideNavbar() {
  return (
    <>
      <div className="list-group ">
        <Link
          style={{ background: "#6068bf" }}
          to="/admin"
          className="list-group-item list-group-item-action active "
        >
          Admin
        </Link>
        <Link
          to="/admin-users"
          className="list-group-item list-group-item-action"
        >
          <i className="fa fa-users sidebar-icon"></i>
          <span className="adminSidebar">Users</span>
        </Link>
        <Link
          to="/admin-maincategories"
          className="list-group-item list-group-item-action"
        >
          <i className="fa fa-bars sidebar-icon"></i>
          <span className="adminSidebar">Maincategories</span>
        </Link>
        <Link
          to="/admin-subcategories"
          className="list-group-item list-group-item-action"
        >
          <i className="fa fa-list sidebar-icon"></i>
          <span className="adminSidebar">Subcategories</span>
        </Link>
        <Link
          to="/admin-brands"
          className="list-group-item list-group-item-action"
        >
          <i className=" fa fa-tag sidebar-icon"></i>
          <span className="adminSidebar">Brands</span>
        </Link>
        <Link
          to="/admin-products"
          className="list-group-item list-group-item-action"
        >
          <i className="fa-brands fas fa-th-large sidebar-icon"></i>
          <span className="adminSidebar">Products</span>
        </Link>
        <Link
          to="/admin-contacts"
          className="list-group-item list-group-item-action"
        >
          <i className=" fa fa-envelope sidebar-icon"></i>
          <span className="adminSidebar">Contact</span>
        </Link>
        <Link
          to="/admin-checkouts"
          className="list-group-item list-group-item-action"
        >
          <i className=" fa fa-shopping-cart sidebar-icon"></i>
          <span className="adminSidebar">Checkouts</span>
        </Link>
        <Link
          to="/admin-newslatters"
          className="list-group-item list-group-item-action"
        >
          <i className=" fa fa-star sidebar-icon"></i>
          <span className="adminSidebar">NewsLatter</span>
        </Link>
      </div>
    </>
  );
}
