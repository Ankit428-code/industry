import React, { useState, useEffect } from "react";
import SideNavbar from "./SideNavbar";
import { DataGrid } from "@mui/x-data-grid";
import { Button } from "@mui/material";
import { apiLink } from "../../utils/utils";

export default function Users() {
  var [user, setUser] = useState([]);
  const columns = [
    { field: "_id", headerName: "ID", width: 220 },
    { field: "name", headerName: "Name", width: 130 },
    { field: "email", headerName: "Email", width: 250 },
    { field: "phone", headerName: "Phone", width: 130 },
    { field: "role", headerName: "Role", width: 100 },
    {
      field: "delete",
      headerName: "Delete",
      sortable: false,
      renderCell: ({ row }) => (
        <Button
          onClick={() => {
            deleteItem(row.id);
          }}
        >
          <i className="fa fa-trash"></i>
        </Button>
      ),
    },
  ];
  var rows = [];
  if (user.length) {
    for (let item of user) rows.push(item);
  }
  async function getAPIData() {
    var response = await fetch(`${apiLink}/api/user`, {
      method: "get",
      headers: {
        "content-type": "application/json",
        authorization: localStorage.getItem("token"),
      },
    });
    response = await response.json();
    if (response.result === "Done") setUser(response.data);
  }
  async function deleteItem(_id) {
    if (window.confirm("Are Your Sure You Want to Delete that Item :")) {
      var response = await fetch(`${apiLink}/api/user/` + _id, {
        method: "delete",
        headers: {
          "content-type": "application/json",
          authorization: localStorage.getItem("token"),
        },
      });
      await response.json();
      getAPIData();
    }
  }
  useEffect(() => {
    getAPIData();
    // eslint-disable-next-line
  }, []);
  return (
    <>
      <div className="container-fluid">
        <div className="row">
          <div className="col-md-3 col-12">
            <SideNavbar />
          </div>
          <div className="col-md-9 col-12">
            <h5 className="header-color text-center p-2">Users</h5>
            <div style={{ height: 400, width: "100%" }}>
              <DataGrid
                getRowId={(row) => row._id}
                rows={rows}
                columns={columns}
                pageSize={5}
                rowsPerPageOptions={[5]}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
