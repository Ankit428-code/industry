import React, { useEffect, useState } from "react";
import SideNavbar from "./SideNavbar";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

import formValidation from "../CustomValidation/formValidation";
import { addProduct } from "../../Store/ActionCreators/ProductActionCreators";
import { getMaincategory } from "../../Store/ActionCreators/MaincategoryActionCreators";
import { getSubcategory, } from "../../Store/ActionCreators/SubcategoryActionCreators";
import { getBrand, } from "../../Store/ActionCreators/BrandActionCreators";

export default function AddProduct() {
  let [errorMessage, setErrorMessage] = useState({
    name: "Product Name Must Required",
    color: "Color Must required ",
    size: "Size Must Required",
    pole:"pole must be required",
    rating:"rating must be required",
    baseprice: "Baseprice Must Required",
    discount: "Discount Must Required",
    pic1: "Pic1 Must Required",
  });
  let [show, setShow] = useState(false);
  let [data, setData] = useState({
    name: "",
    maincategory: "",
    subcategory: "",
    brand: "",
    color: "",
    size: "",
    rating: "",
    pole: "",
    baseprice: "",
    discount: "",
    finalprice: "",
    stock: "In Stock",
    specification: "",
    description: "This is a sample Product",
    pic1: "",
    pic2: "",
    pic3: "",
    pic4: "",
  });
  let [maincategory, setMaincategory] = useState([]);
  let [subcategory, setSubcategory] = useState([]);
  let [brand, setBrand] = useState([]);
  let navigate = useNavigate();
  let dispatch = useDispatch();
  let allmaincategories = useSelector((state) => state.MaincategoryStateData);
  let allsubcategories = useSelector((state) => state.SubcategoryStateData);
  let allbrands = useSelector((state) => state.BrandStateData);

  const [specsData, setSpecsData] = useState([{ key: "", value: "" }]);

  const handleInputChange = (index, keyOrValue, newValue) => {
    const updatedFormData = [...specsData];
    updatedFormData[index][keyOrValue] = newValue;
    setSpecsData(updatedFormData);
  };

  const handleAddPair = () => {
    setSpecsData([...specsData, { key: "", value: "" }]);
  };

  const handleRemovePair = (index) => {
    const updatedFormData = [...specsData];
    updatedFormData.splice(index, 1);
    setSpecsData(updatedFormData);
  };
  function getInputData(e) {
    let { name, value } = e.target;
    setErrorMessage((old) => {
      return {
        ...old,
        [name]: formValidation(e),
      };
    });
    setData((old) => {
      return {
        ...old,
        [name]: value,
      };
    });
  }
  function getInputFile(e) {
    let { name, files } = e.target;
    if (name === "pic1") {
      setErrorMessage((old) => {
        return {
          ...old,
          [name]: "",
        };
      });
    }
    setData((old) => {
      return {
        ...old,
        [name]: files[0],
      };
    });
  }
  async function postData(e) {
    e.preventDefault();
    let error = Object.keys(errorMessage).find(
      (x) => errorMessage[x] && errorMessage[x].length !== 0
    );
    if (!error) {
      let fp = Math.round(
        data.baseprice - (data.baseprice * data.discount) / 100
      );
      var item = new FormData();
      item.append("name", data.name);
      item.append("maincategory", data.maincategory || maincategory[0]?.name);
      item.append("subcategory", data.subcategory || subcategory[0]?.name);
      item.append("brand", data.brand || brand[0].name);
      item.append("color", data.color);
      item.append("size", data.size);
      item.append("rating", data.rating);
      item.append("pole", data.pole);
      item.append("baseprice", parseInt(data.baseprice));
      item.append("discount", parseInt(data.discount));
      item.append("finalprice", fp);
      item.append("stock", data.stock);
      item.append("description", data.description);
      item.append("pic1", data.pic1);
      item.append("pic2", data.pic2);
      item.append("pic3", data.pic3);
      item.append("pic4", data.pic4);
      item.append("specification", JSON.stringify(specsData));
      dispatch(addProduct(item));
      navigate("/admin-products");
    } else setShow(true);
  }
  function getAPIData() {
    dispatch(getMaincategory());
    dispatch(getSubcategory());
    dispatch(getBrand());
    if (allmaincategories.length) setMaincategory(allmaincategories);
    if (allsubcategories.length) setSubcategory(allsubcategories);
    if (allbrands.length) setBrand(allbrands);
  }
  const handleChange = (e) => {
    getInputData(e);
    dispatch(getSubcategory(e.target.value));
  };
  const handleSubCategoryChange = (e) => {
    getInputData(e);
    dispatch(getBrand(e.target.value));
  };

  useEffect(() => {
    getAPIData();
    // eslint-disable-next-line
  }, []);

  return (
    <>
      <div className="container-fluid my-3">
        <div className="row">
          <div className="col-md-3">
            <SideNavbar />
          </div>
          <div className="col-md-9">
            <h5 className="header-color p-2 text-center">Product</h5>
            <form onSubmit={postData}>
              <div className="mb-3">
                <label>Name</label>
                <input
                  type="text"
                  name="name"
                  onChange={getInputData}
                  className="form-control"
                  placeholder="Name"
                />
                {show ? <p className="text-danger">{errorMessage.name}</p> : ""}
              </div>
              <div className="row">
                <div className="col-md-3 mb-3">
                  <label>Maincategory</label>
                  <select
                    name="maincategory"
                    onChange={handleChange}
                    className="form-control"
                  >
                    <option>Select Category</option>
                    {allmaincategories.map((item, index) => {
                      return (
                        <option key={index} value={item._id}>
                          {item.name}
                        </option>
                      );
                    })}
                  </select>
                </div>
                <div className="col-md-3 mb-3">
                  <label>Subcategory</label>
                  <select
                    name="subcategory"
                    onChange={handleSubCategoryChange}
                    className="form-control"
                  >
                    <option>Select Category</option>
                    {allsubcategories.map((item, index) => {
                      return (
                        <option key={index} value={item._id}>
                          {item.name}
                        </option>
                      );
                    })}
                  </select>
                </div>
                <div className="col-md-3 mb-3">
                  <label>Brand</label>
                  <select
                    name="brand"
                    onChange={getInputData}
                    className="form-control"
                  >
                    <option>Select Category</option>
                    {allbrands.map((item, index) => {
                      return (
                        <option key={index} value={item._id}>
                          {item.name}
                        </option>
                      );
                    })}
                  </select>
                </div>
                <div className="col-md-3 mb-3">
                  <label>Stock</label>
                  <select
                    name="stock"
                    onChange={getInputData}
                    className="form-control"
                  >
                    <option value="In Stock">In Stock</option>
                    <option value="Out Of Stock">Out Of Stock</option>
                  </select>
                </div>
              </div>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label>Color</label>
                  <input
                    type="text"
                    name="color"
                    placeholder="color"
                    onChange={getInputData}
                    className="form-control"
                  />
                  {show ? (
                    <p className="text-danger">{errorMessage.color}</p>
                  ) : (
                    ""
                  )}
                </div>
                <div className="col-md-6 mb-3">
                   <label>Size</label>
                  <input
                    type="text"
                    name="size"
                    placeholder="size"
                    onChange={getInputData}
                    className="form-control"
                  />
                  {show ? (
                    <p className="text-danger">{errorMessage.size}</p>
                  ) : (
                    ""
                  )}
                </div>
                <div className="col-md-6 mb-3">
                  <label>Rating</label>
                  <input type="text"
                    name="rating"
                    placeholder="rating"
                    onChange={getInputData}
                    className="form-control" />
                    {show? (
                      <p className="text-danger">{errorMessage.rating}</p>
                    ):(
                      ""
                    )}

                </div>
                <div className="col-md-6 mb-3">
                  <label>Pole</label>
                  <input type="text"
                    name="rating"
                    placeholder="pole"
                    onChange={getInputData}
                    className="form-control" />
                    {show? (
                      <p className="text-danger">{errorMessage.pole}</p>
                    ):(
                      ""
                    )}

                </div>
              </div>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label>Base Price</label>
                  <input
                    type="number"
                    name="baseprice"
                    placeholder="Base Price"
                    onChange={getInputData}
                    className="form-control"
                  />
                  {show ? (
                    <p className="text-danger">{errorMessage.baseprice}</p>
                  ) : (
                    ""
                  )}
                </div>
                <div className="col-md-6 mb-3">
                  <label>Discount</label>
                  <input
                    type="number"
                    name="discount"
                    placeholder="Discount"
                    min={0}
                    onChange={getInputData}
                    className="form-control"
                  />
                  {show ? (
                    <p className="text-danger">{errorMessage.discount}</p>
                  ) : (
                    ""
                  )}
                </div>
              </div>
              <div className="inputField">
                <label>Specification</label>
                <div>
                  {specsData.map((pair, index) => (
                    <div className="row mb-2" key={index}>
                      <div className="col-md-4">
                        <input
                          type="text"
                          name="skey"
                          onChange={(e) =>
                            handleInputChange(index, "key", e.target.value)
                          }
                          className="form-control"
                          placeholder="Enter Specification Key :"
                        />
                        {show ? (
                          <p className="text-danger">
                            {errorMessage.specification}
                          </p>
                        ) : (
                          ""
                        )}
                      </div>
                      <div className="col-md-4">
                        <input
                          type="text"
                          name="sval"
                          onChange={(e) =>
                            handleInputChange(index, "value", e.target.value)
                          }
                          className="form-control"
                          placeholder="Enter Specification Value :"
                        />
                      </div>
                      <div className="col-md-3">
                        <button
                          type="button"
                          className="btn header-color w-100"
                          onClick={() => handleRemovePair(index)}
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                  <div className="row">
                    <div className="col-md-3">
                      <button
                        type="button"
                        className="btn bg-success text-white w-100"
                        onClick={handleAddPair}
                      >
                        Add
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mb-3">
                <label>Description</label>
                <textarea
                  name="description"
                  rows="5"
                  className="form-control"
                  placeholder="Description..."
                  onChange={getInputData}
                  value={data.description}
                ></textarea>
              </div>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label>Pic1</label>
                  <input
                    type="file"
                    name="pic1"
                    onChange={getInputFile}
                    className="form-control"
                  />
                  {show ? (
                    <p className="text-danger">{errorMessage.pic1}</p>
                  ) : (
                    ""
                  )}
                </div>
                <div className="col-md-6 mb-3">
                  <label>Pic2</label>
                  <input
                    type="file"
                    name="pic2"
                    onChange={getInputFile}
                    className="form-control"
                  />
                </div>
                <div className="col-md-6 mb-3">
                  <label>Pic3</label>
                  <input
                    type="file"
                    name="pic3"
                    onChange={getInputFile}
                    className="form-control"
                  />
                </div>
                <div className="col-md-6 mb-3">
                  <label>Pic4</label>
                  <input
                    type="file"
                    name="pic4"
                    onChange={getInputFile}
                    className="form-control"
                  />
                </div>
              </div>
              <div className="mb-3">
                <button
                  type="button"
                  className="btn btn-success w-50"
                  onClick={() => window.history.back()}
                >
                  Back
                </button>
                <button type="submit" className="btn header-color w-50">
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}
