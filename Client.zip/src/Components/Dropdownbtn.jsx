import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

// import SingleProduct from './SingleProduct'
// import { RxCaretDown } from "react-icons/rx";



const Dropdownbtn = () => {

  const [ratedCurrentOpen, setRatedCurrentOpen] = useState(false);
  const [polesOpen, setPolesOpen] = useState(false)

  const ratedCurrentData = {
    isOpen: ratedCurrentOpen,
    items: [
      { label: '63Amp' },
      { label: '30Amp' },
      { label: '46Amp' },
      { label: '16Amp' }
    ]
  };

  const polesData = {
    isOpen: polesOpen,
    items: [
      { label: 'Pole 1' },
      { label: 'Pole 2' },
      { label: 'Pole 3' },
      { label: 'Pole 4' },
    ]
  };


  const toggleRatedCurrentDropdown = () => {
    setRatedCurrentOpen(!ratedCurrentOpen);
    setPolesOpen(false);
  }

  const togglePolesDropdown = () => {
    setPolesOpen(!polesOpen);
    setRatedCurrentOpen(false);
  }

  return (

    <div className=''>
      <button
        className="btn main-color px-3 mr-4 mb-3" onClick={toggleRatedCurrentDropdown}>
        Rated Current(A)
        {/* <RxCaretDown onClick={toggleDropdown} /> */}

      </button>
      <button
        className="btn main-color px-3 mr-2 mb-3" onClick={togglePolesDropdown} >
        No. of Pole
        {/* <RxCaretDown onClick={toggleDropdown} />  */}
      </button>

      {ratedCurrentOpen && <DropdownMenu data={ratedCurrentData} />}
      {polesOpen && <DropdownMenu data={polesData} />}

    </div>


  )
}

//DropdownMenu Component, Rated button & Poles =====================================================

const DropdownMenu = ({ data }) => {
  const navigate = useNavigate();

  const handleItemClick = (itemlabel) => {
    console.log(itemlabel)
    if (itemlabel === 'Pole 1') {
      navigate('/pole1')
    }
    else if (itemlabel === 'Pole 2') {
      navigate('/pole2');
    }
    else if (itemlabel === 'Pole 3') {
      navigate('/Pole 3');
    }
    else {
      console.log('Unknown Item Clicked!',itemlabel)
      //navigate('/pole1')
    }
  }
  return (
    <div className="-mx-2">
      <ul className='list-unstyled -ml-9 p- list-group w-25 h-25' >
        {data.items.map((item, index) => (
          <li key={index} className='list-group-item  text-white  px-3 mr-5 mb-0 '
            style={{ backgroundColor: 'rgb(96 104 191)', cursor: 'pointer', border: '' }} onClick={() =>handleItemClick(item.label)}>
            {item.label}
          </li>
        ))}
      </ul>
    </div>
  );
};
export default Dropdownbtn;
