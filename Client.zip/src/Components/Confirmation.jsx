import React, { useEffect, useState } from "react";

export default function Confirmation() {
  const [userID, setUserID] = useState("");

  useEffect(() => {
    // Retrieve orderID from local storage
    const storedOrderID = localStorage.getItem("userid");
    setUserID(storedOrderID || "");
  }, []);

  return (
    <div className="container-fluid my-3 text-center">
      {/* <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGJ74Y-ZdCTIfN85S3Od7muxTJ5owLp6a66Q&s" alt="successfull"/> */}
      <h2>Your Order ID: {userID}</h2>
      <h2 className="text-success">Thank You!!!</h2>

      <h3>Your Order Has Been Placed!!!</h3>
      <h4>Now You Can Track Your Order in Profile Section</h4>
    </div>
  );
}
