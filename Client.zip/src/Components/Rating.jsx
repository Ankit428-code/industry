import React, { useState } from 'react';

const RatingPage = () => {
  const [rating, setRating] = useState(0);

  const handleRatingChange = (newRating) => {
    setRating(newRating);
  };

  const handleSubmitRating = () => {
    console.log('Rating submitted:', rating);
    setRating(0);
  };

  return (
    <div>
      <h2>Rate this page:</h2>
      <div>
        {[1, 2, 3, 4, 5].map((value) => (
          <button
            key={value}
            onClick={() => handleRatingChange(value)}
            style={{ backgroundColor: rating >= value ? 'gold' : 'transparent' }}
          >
            {value}
          </button>
        ))}
      </div>
      <button onClick={handleSubmitRating}>Submit Rating2</button>
    </div>
  );
};

export default RatingPage;