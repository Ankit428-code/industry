// import React, { useEffect } from "react";
// import { Link } from "react-router-dom";
// import { useDispatch, useSelector } from "react-redux";
// import { getSubcategory } from "../Store/ActionCreators/SubcategoryActionCreators";

// const ClientSidebar = () => {
//   var allSubcategories = useSelector((state) => state.SubcategoryStateData);
//   var dispatch = useDispatch();

//   useEffect(() => {
//     dispatch(getSubcategory());
//     // eslint-disable-next-line
//   }, []);
//   return (
//     <>
//       <div className="list-group ">
//         <div
//           style={{ background: "#6068bf" }}
//           className="list-group-item list-group-item-action active "
//         >
//           All Categories
//         </div>
//         <div
//           className="list-group "
//           style={{ height: "24rem", overflow: "auto" }}
//         >
//           {allSubcategories.map((item, index) => (
//             <Link
//               key={index}
//               to={`/shop/${item._id}/All/All`}
//               className="list-group-item list-group-item-action"
//             >
//               <span className="float-start">{item.name}</span>
//             </Link>
//           ))}
//         </div>
//       </div>
//     </>
//   );
// };

// export default ClientSidebar;



import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getSubcategory } from "../Store/ActionCreators/SubcategoryActionCreators";

const ClientSidebar = () => {
  const allSubcategories = useSelector((state) => state.SubcategoryStateData);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getSubcategory());
  }, [dispatch]);

  return (
    <div className="list-group">
      <div
        style={{ background: "#6068bf" }}
        className="list-group-item list-group-item-action active"
      >
        All Categories
      </div>
      <div className="list-group" style={{ height: "24rem", overflow: "auto" }}>
        {allSubcategories.map((item, index) => (
          <Link
            key={index}
            to={`/shop/${item.maincat}/${item._id}/All`}
            className="list-group-item list-group-item-action"
          >
            <span className="float-start">{item.name}</span>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default ClientSidebar;
