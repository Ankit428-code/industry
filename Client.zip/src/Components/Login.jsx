import React, { useState,useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { apiLink } from "../utils/utils";
import { FetchUser } from "../Store/Services/AuthService";
import { useAuth0 } from "@auth0/auth0-react";

export default function Login() {
  const {loginWithRedirect} = useAuth0()
  var [data, setData] = useState({
    username: "",
    password: "",
  });
  var navigate = useNavigate();
  function getInputData(e) {
    var { name, value } = e.target;
    setData((old) => {
      return {
        ...old,
        [name]: value,
      };
    });
  }
  async function postData(e) {
    e.preventDefault();
    var response = await fetch(`${apiLink}/api/user/login`, {
      method: "post",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify(data),
    });
    response = await response.json();
    if (response.result === "Done") {
      localStorage.setItem("login", true);
      localStorage.setItem("username", response.data.username);
      localStorage.setItem("name", response.data.name);
      localStorage.setItem("userid", response.data._id);
      localStorage.setItem("role", response.data.role);
      localStorage.setItem("token", response.token);
      if (response.data.role === "Admin") navigate("/admin");
      else if (response.data.role === "Vendor") navigate("/vendor");
      else navigate("/profile");
    } else alert(response.message);
  }

  const [user, setUser] = useState(null);
    useEffect(() => {
      FetchUser().then((data)=> setUser(data))
      .catch(() => setUser(null))
    }, [])

    // Function to handle Google Login
  const handleGoogleLogin = () =>{
    window.open(`${apiLink}/api/google`, '_self')

  }
  return (
    <div className="container-fluid my-3">
      <div className="w-50 m-auto">
        <h5 className="header-color text-center p-2">
          <span className="text-info">Login</span> To Your Account
        </h5>
        <form onSubmit={postData}>
          <div className="mb-3">
            <label>User Name</label>
            <input
              type="text"
              required
              onChange={getInputData}
              name="username"
              placeholder="Enter User Name"
              className="form-control"
            />
          </div>
          <div className="mb-3">
            <label>Password</label>
            <input
              type="password"
              required
              onChange={getInputData}
              name="password"
              placeholder="Enter Password"
              className="form-control"
            />
          </div>
          <div className="mb-3">
            <button type="submit" className="btn main-color w-100">
              Login
            </button>
          </div>
        </form>
        <div className="mb-3">
          <button onClick={(e) => loginWithRedirect()} className="btn btn-danger w-100">
          <i className="bi bi-google"></i> Login with Google
          </button>
        </div>
        <div className="d-flex justify-content-between">
          <Link to="/forget-password-1" className="text-info">
            Forget Password
          </Link>
          <Link to="/signup" className="text-info">
            New User?Create a Free Account
          </Link>
        </div>
      </div>
    </div>
  );
}
