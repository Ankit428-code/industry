// export const apiLink = "https://api.industryguru.in";
export const apiLink = "http://localhost:8001";
